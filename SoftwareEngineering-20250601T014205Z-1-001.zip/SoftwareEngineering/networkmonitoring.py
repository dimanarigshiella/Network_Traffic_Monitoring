from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO
import socket
import platform
import psutil
import subprocess
import threading
import time
import nmap
from scapy.all import sniff, IP, TCP, UDP, Raw, get_if_list, conf, get_if_addr

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# Get Local Device Info
def get_local_device_info():
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    return {
        "hostname": hostname,
        "ip_address": ip_address,
        "os": platform.system(),
        "os_version": platform.version(),
        "processor": platform.processor(),
        "cpu_count": psutil.cpu_count(logical=True),
        "ram_total": round(psutil.virtual_memory().total / (1024**3), 2)
    }

# Get Connected Devices Across the Network
def get_connected_devices():
    nm = nmap.PortScanner()
    nm.scan(hosts="192.168.1.0/24", arguments="-sn")
    devices = []
    for host in nm.all_hosts():
        devices.append({
            "ip": host,
            "hostname": nm[host].hostname(),
            "mac": nm[host]["addresses"].get("mac", "Unknown"),
            "network_usage": get_device_network_usage(host)
        })
    return devices

# Get Network Usage for a Specific Device and convert bytes to MB
def get_device_network_usage(ip):
    net_io = psutil.net_io_counters(pernic=True)
    usage = {"bytes_sent": 0, "bytes_received": 0}
    for interface, stats in net_io.items():
        usage["bytes_sent"] += stats.bytes_sent
        usage["bytes_received"] += stats.bytes_recv
    
    # Convert bytes to MB (1 MB = 1024 * 1024 bytes)
    usage["bytes_sent"] = round(usage["bytes_sent"] / (1024**2), 2)
    usage["bytes_received"] = round(usage["bytes_received"] / (1024**2), 2)
    
    return usage

# Identify Web Apps Based on Hostname in Packets (Support multiple apps)
def identify_web_activity(packet):
    if packet.haslayer(Raw):
        payload = packet[Raw].load.decode(errors="ignore")
        apps = []
        if "youtube.com" in payload:
            apps.append("YouTube")
        elif "facebook.com" in payload:
            apps.append("Facebook")
        elif "netflix.com" in payload:
            apps.append("Netflix")
        elif "tiktok.com" in payload:
            apps.append("TikTok")
        elif "instagram.com" in payload:
            apps.append("Instagram")
        elif "twitter.com" in payload:
            apps.append("Twitter")
        elif "chat.openai.com" in payload:
            apps.append("ChatGPT")
        elif "chatgpt.com" in payload:
            apps.append("ChatGPT")
        
        # If any web app found, return the list
        if apps:
            return apps
    return []

# Get Network Interface Dynamically and Set to Promiscuous Mode
def get_network_interface():
    # Check if the system is Windows or Linux/macOS and choose the correct interface
    if platform.system() == "Windows":
        interfaces = get_if_list()
        # Here, choose the interface that suits your network setup (e.g., "Wi-Fi" or "Ethernet")
        for interface in interfaces:
            print(f"Found interface: {interface}")
        return "Wi-Fi"  # Change this based on your actual interface
    else:
        # For Linux/macOS, the interface could be "eth0" or "wlan0" depending on your network
        return "eth0"  # You can update this if you're on Wi-Fi

# Sniff Packets Asynchronously for all devices
def sniff_packets():
    def packet_callback(packet):
        if IP in packet and (TCP in packet or UDP in packet):
            src_ip = packet[IP].src
            detected_apps = identify_web_activity(packet)
            if detected_apps:
                # Emit the detected apps for the source IP along with its network usage
                socketio.emit("packet", {
                    "src_ip": src_ip, 
                    "apps": detected_apps, 
                    "data_usage": get_device_network_usage(src_ip)
                })
    
    # Get network interface dynamically
    interface = get_network_interface()
    print(f"Sniffing on interface: {interface}")
    
    # Set the interface to promiscuous mode to capture all packets on the network
    conf.iface = interface
    conf.promisc = True  # Enable promiscuous mode

    # Only sniff HTTP(S) traffic to avoid irrelevant data (customize as needed)
    sniff(filter="tcp port 80 or tcp port 443", prn=packet_callback, store=False, iface=interface)

# Update connected devices and emit them every 1 second
def update_connected_devices():
    while True:
        devices = get_connected_devices()
        socketio.emit('connected_devices', devices)  # Emit the connected devices
        time.sleep(1)  # Sleep for 1 second before refreshing

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/device_info')
def device_info():
    return jsonify(get_local_device_info())

@app.route('/device_usage/<ip>')
def device_usage(ip):
    return jsonify(get_device_network_usage(ip))

# Start packet sniffing in a separate thread
threading.Thread(target=sniff_packets, daemon=True).start()

# Start device update in a separate thread
threading.Thread(target=update_connected_devices, daemon=True).start()

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5000)
